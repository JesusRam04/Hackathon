function fetchAndDisplayRecipes() {
    const apiUrl = 'https://www.themealdb.com/api/json/v1/1/search.php?f=a';
  
    fetch(apiUrl)
      .then(response => response.json())
      .then(data => {
        console.log('Recipes data:', data);
        const recipes = data.meals;
        // ... Rest of the code to display recipes ...
      })
      .catch(error => console.error('Error fetching recipes:', error));
  }
  
  window.onload = function() {
    // ... Other initialization code ...
  
    console.log('Initializing fetchAndDisplayRecipes function.');
  
    const fetchRecipesButton = document.getElementById('fetch-recipes-button');
    fetchRecipesButton.addEventListener('click', fetchAndDisplayRecipes);
  };
  