// Definir un objeto para representar un alimento
function Alimento(nombre, tipo, fechaDeCaducidad) {
    this.nombre = nombre;
    this.cantidad = 0;
    this.tipo = tipo;
    this.fechaCaducidad = fechaCaducidad;
  }
  
  // Crear instancias de alimentos
  var verduras = [
    new Alimento("Cebolla", "verduras", "2023-12-31"),
    new Alimento("Ajo", "verduras", "2023-12-31"),
    new Alimento("Zanahoria", "verduras", "2023-12-31"),
    new Alimento("Champinon", "verduras", "2023-12-31"),
    new Alimento("Patata", "verduras", "2023-12-31"),
    new Alimento("Tomate", "verduras", "2023-12-31")
    // Agrega más verduras si es necesario
  ];
  
  var carnes = [
    new Alimento("Pollo", "carnes", "2023-12-31"),
    new Alimento("Res", "carnes", "2023-12-31"),
    new Alimento("Pescado", "carnes", "2023-12-31")
    // Agrega más carnes si es necesario
  ];
  
  var lacteos = [
    new Alimento("Leche", "lacteos", "2023-12-31"),
    new Alimento("Queso", "lacteos", "2023-12-31"),
    new Alimento("Mantequilla", "lacteos", "2023-12-31")
    // Agrega más lácteos si es necesario
  ];
  
  function actualizarContador(alimento) {
    var elementId = `${alimento.tipo}-${alimento.nombre.replace(/\s+/g, '-').toLowerCase()}-count`;
    document.getElementById(elementId).innerHTML = alimento.cantidad;
  }
  
  function incrementarCantidad(alimento) {
    alimento.cantidad++;
    actualizarContador(alimento);
  }
  
  function decrementarCantidad(alimento) {
    if (alimento.cantidad > 0) {
      alimento.cantidad--;
      actualizarContador(alimento);
    }
  }
  
  
  function mostrarAlimento(tipo) {
    var alimentos;
    if (tipo === 'verduras') {
      alimentos = verduras;
    } else if (tipo === 'carnes') {
      alimentos = carnes;
    } else if (tipo === 'lacteos') {
      alimentos = lacteos;
    }
  
    var elementId = `${tipo}`;
    var display = document.getElementById(elementId).style.display;
    document.getElementById(elementId).style.display = (display === "none" || display === "") ? "block" : "none";
  }



  window.onload = function() {

    mostrarAlimento('verduras'); // Mostrar las verduras por defecto al cargar la página
    mostrarAlimento('carnes'); // Mostrar las carnes por defecto al cargar la página
    mostrarAlimento('lacteos'); // Mostrar los lacteos por defecto al cargar la página
    restaurarContadores();
  }
  
  
  