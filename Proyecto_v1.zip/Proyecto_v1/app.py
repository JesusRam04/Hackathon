from flask import Flask, render_template, Response, request, jsonify
import cv2
import pyzbar.pyzbar as pyzbar
import numpy as np
from collections import Counter
import json
import requests
import csv

app = Flask(__name__)

global_control = 0
data_list = []
most_common_value = ""

def Cleaning(frame):
    # Converting the color space of the frame to gray scale
    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)

    # Applying Gaussian filter
    gaussian = cv2.GaussianBlur(gray, (3, 3), 0)

    # Returning the cleaned frame
    return gaussian

def Decoding(gaussian):
    # Decoding the object extracted from barcode and QR code within a frame
    decodes = pyzbar.decode(gaussian)

    # Returning the decoded object
    return decodes

def Drawing(decodes, frame):
    # Looping to use an object by object
    for decode in decodes:
        # Getting the coordinates of vertices from information for polygon of the decoded object
        coordinates = decode.polygon

        # Converting the coordinates to array format with int32
        points = np.array(coordinates, np.int32)

        # Making the coordinates like a contour but it is still required to connect
        hull = cv2.convexHull(points)

        # Connecting the coordinates with closing lines
        cv2.polylines(frame, [hull], True, (0, 255, 0), 3)

def Texting(decodes, frame):
    data = []
    type = []
    control = False

    # Looping to use an object by object
    for decode in decodes:
        # Storing the data from information of the decoded object
        data = decode.data.decode('ascii')

        # Storing the type from information of the decoded object
        type = decode.type

        text = data + ' [' + type + ']'

        print(text)

        # Obtaining the location of the most left and upper side vertex
        x, y, _, _ = decode.rect

        # Putting the text at the coordinate of the vertex
        cv2.putText(frame, text, (x, y - 10), cv2.FONT_HERSHEY_PLAIN, 1.5, (0, 0, 255), 2)
        if text != "":
            control = True

    return data, type, control

def WorkingAdditional(option):
    exit = False

    # Press 'q' to exit
    if option == ord('q'):
        print('Closing Detector')
        exit = True

    return exit

def Barcode_Detector(frame):
    # Cleaning
    gaussian = Cleaning(frame)

    # Decoding
    decodes = Decoding(gaussian)

    # Drawing
    Drawing(decodes, frame)

    # Texting
    data, type, control = Texting(decodes, frame)

    # User input
    option = cv2.waitKey(1)

    # Additional job
    commend = WorkingAdditional(option)

    return commend, control, data



def get_product_info(code):
    url1 = "https://world.openfoodfacts.org/api/v2/product/" + code + ".json"
    new_data = []

    info_product = requests.get(url1)
    data = json.loads(info_product.text)

    nombre = data["product"].get("product_name", "")
    new_data.append(nombre)

    cantidad = data["product"].get("quantity", "")
    new_data.append(cantidad)

    # Tabla de información nutricional
    if data["product"].get("nutriments", "0") != "0":
        enegy = data["product"]["nutriments"].get("energy_100g", "")
        enegy_unit = data["product"]["nutriments"].get("energy_unit", "")
        new_data.append(enegy)
        fat = data["product"]["nutriments"].get("fat_100g", "")
        fat_unit = data["product"]["nutriments"].get("fat_unit", "")
        new_data.append(fat)
        saturated_fat = data["product"]["nutriments"].get("saturated-fat_100g", "")
        saturated_fat_unit = data["product"]["nutriments"].get("saturated-fat_unit", "")
        new_data.append(saturated_fat)
        sodium = data["product"]["nutriments"].get("sodium_100g", "")
        sodium_unit = data["product"]["nutriments"].get("sodium_unit", "")
        new_data.append(sodium)
        carbohidratos = data["product"]["nutriments"].get("carbohydrates_100g", "")
        carbohidratos_unit = data["product"]["nutriments"].get("carbohydrates_unit", "")
        new_data.append(carbohidratos)
        sugar = data["product"]["nutriments"].get("sugars_100g", "")
        sugar_unit = data["product"]["nutriments"].get("sugars_unit", "")
        new_data.append(sugar)
        proteina = data["product"]["nutriments"].get("proteins_100g", "")
        proteina_unit = data["product"]["nutriments"].get("proteins_unit", "")
        new_data.append(proteina)
        salt = data["product"]["nutriments"].get("salt_100g", "")
        salt_unit = data["product"]["nutriments"].get("salt_unit", "")
        new_data.append(salt)
    else:
        new_data.append("")
        new_data.append("")
        new_data.append("")
        new_data.append("")
        new_data.append("")
        new_data.append("")
        new_data.append("")
        new_data.append("")
    if data["product"].get("nutriscore_data", "0") != "0":
        fiber = data["product"]["nutriscore_data"].get("fiber_value", "")
        new_data.append(fiber)
    else:
        new_data.append("")
        
    datos_para_csv = {
        'Name': new_data[0],
        'Quantity': new_data[1],
        'Energy': new_data[2],
        'Fat': new_data[3],
        'Saturated_fat': new_data[4],
        'Sodium': new_data[5],
        'Carbohydrates': new_data[6],
        'Sugar': new_data[7],
        'Protein': new_data[8],
        'Salt': new_data[9],
        'Fiber': new_data[10]
}
        
    with open("info.csv", mode='w', newline='') as file:
        encabezados = ['Name', 'Quantity', 'Energy', 'Fat', 'Saturated_fat', 'Sodium', 'Carbohydrates', 'Sugar', 'Protein', 'Salt', 'Fiber']
        escritor_csv = csv.DictWriter(file, fieldnames=encabezados)
        escritor_csv.writeheader()
        escritor_csv.writerow(datos_para_csv)
        
    return new_data

most_common_value = ""

@app.route('/')
def index():
    global most_common_value
    product_info = []  # Inicializamos product_info como una lista vacía
    if most_common_value:
        product_info = get_product_info(most_common_value)
    return render_template('index.html', most_common_value=most_common_value, product_info=product_info)

def gen():
    global global_control
    global most_common_value  # Agregar esta línea
    global_control = 0
    cap = cv2.VideoCapture(0)
    cap.set(3, 600)
    cap.set(4, 400)

    while (cap.isOpened()):
        frame = cap.read()[1]
        commend, control, data = Barcode_Detector(frame)

        if control == True:
            global_control = global_control + 1
            data_list.append(str(data))
            counter = Counter(data_list)
            most_common = counter.most_common(1)
            most_common_value, count = most_common[0]

        ret, jpeg = cv2.imencode('.jpg', frame)
        frame = jpeg.tobytes()
        yield (b'--frame\r\n'
               b'Content-Type: image/jpeg\r\n\r\n' + frame + b'\r\n')
        
        if commend == True or global_control == 10:
            #print('last call', most_common_value)
            break
        
    url1 = "https://world.openfoodfacts.org/api/v2/product/" + most_common_value + ".json"
    new_data = []

    info_product = requests.get(url1)
    data = json.loads(info_product.text)

    nombre = data["product"].get("product_name", "")
    new_data.append(nombre)

    cantidad = data["product"].get("quantity", "")
    new_data.append(cantidad)

    # Tabla de información nutricional
    if data["product"].get("nutriments", "0") != "0":
        enegy = data["product"]["nutriments"].get("energy_100g", "")
        enegy_unit = data["product"]["nutriments"].get("energy_unit", "")
        new_data.append(enegy)
        fat = data["product"]["nutriments"].get("fat_100g", "")
        fat_unit = data["product"]["nutriments"].get("fat_unit", "")
        new_data.append(fat)
        saturated_fat = data["product"]["nutriments"].get("saturated-fat_100g", "")
        saturated_fat_unit = data["product"]["nutriments"].get("saturated-fat_unit", "")
        new_data.append(saturated_fat)
        sodium = data["product"]["nutriments"].get("sodium_100g", "")
        sodium_unit = data["product"]["nutriments"].get("sodium_unit", "")
        new_data.append(sodium)
        carbohidratos = data["product"]["nutriments"].get("carbohydrates_100g", "")
        carbohidratos_unit = data["product"]["nutriments"].get("carbohydrates_unit", "")
        new_data.append(carbohidratos)
        sugar = data["product"]["nutriments"].get("sugars_100g", "")
        sugar_unit = data["product"]["nutriments"].get("sugars_unit", "")
        new_data.append(sugar)
        proteina = data["product"]["nutriments"].get("proteins_100g", "")
        proteina_unit = data["product"]["nutriments"].get("proteins_unit", "")
        new_data.append(proteina)
        salt = data["product"]["nutriments"].get("salt_100g", "")
        salt_unit = data["product"]["nutriments"].get("salt_unit", "")
        new_data.append(salt)
    else:
        new_data.append("")
        new_data.append("")
        new_data.append("")
        new_data.append("")
        new_data.append("")
        new_data.append("")
        new_data.append("")
        new_data.append("")
    if data["product"].get("nutriscore_data", "0") != "0":
        fiber = data["product"]["nutriscore_data"].get("fiber_value", "")
        new_data.append(fiber)
    else:
        new_data.append("")
        
    datos_para_csv = {
        'Name': new_data[0],
        'Quantity': new_data[1],
        'Energy': new_data[2],
        'Fat': new_data[3],
        'Saturated_fat': new_data[4],
        'Sodium': new_data[5],
        'Carbohydrates': new_data[6],
        'Sugar': new_data[7],
        'Protein': new_data[8],
        'Salt': new_data[9],
        'Fiber': new_data[10]
    }
        
    with open("info.csv", mode='w', newline='') as file:
        encabezados = ['Name', 'Quantity', 'Energy', 'Fat', 'Saturated_fat', 'Sodium', 'Carbohydrates', 'Sugar', 'Protein', 'Salt', 'Fiber']
        escritor_csv = csv.DictWriter(file, fieldnames=encabezados)
        escritor_csv.writeheader()
        escritor_csv.writerow(datos_para_csv)
       
    return new_data
        
@app.route('/procesar_datos', methods=['POST'])
def procesar_datos():
    if request.method == 'POST':
        day = request.form['day']
        month = request.form['month']
        year = request.form['year']
        quantity = request.form['quantity']

        # Abre el archivo CSV y escribe los datos
        with open("user_info_1.csv", mode='a', newline='') as file:
            encabezados = ['Code_bar', 'expire_day', 'expire_month', 'expire_year', 'Quantity']
            escritor_csv = csv.DictWriter(file, fieldnames=encabezados)
            
            # Solo escribimos los encabezados si el archivo está vacío
            if file.tell() == 0:
                escritor_csv.writeheader()
            
            # Escribe los nuevos datos en el archivo
            escritor_csv.writerow({
                'Code_bar': most_common_value,
                'expire_day': day,
                'expire_month': month,
                'expire_year': year,
                'Quantity': quantity
            })

    return "Datos recibidos y guardados en el archivo CSV."

@app.route('/despensa')
def despensa():
    return render_template('index.html')

# Ruta para obtener los datos de la despensa desde el archivo CSV
@app.route('/obtener_despensa')
def obtener_despensa():
    despensa = []

    # Lee los datos desde el archivo CSV (cambia el nombre del archivo si es diferente)
    with open('user_info_1.csv', mode='r') as file:
        reader = csv.DictReader(file)
        for row in reader:
            despensa.append({
                "Producto": row["Code_bar"],
                "Dia": row["expire_day"],
                "Mes": row["expire_month"],
                "Ano": row["expire_year"],
                "Cantidad": row["Quantity"]
            })
            
    for i in range(len(despensa)):   
        barcode = despensa[i]["Producto"]
        url1 = "https://world.openfoodfacts.org/api/v2/product/" + barcode + ".json"
        info_product = requests.get(url1)
        data = json.loads(info_product.text)

        nombre = data["product"].get("product_name", "")
        despensa[i]["Producto"] = nombre
    
    # Devuelve los datos como JSON
    return jsonify(despensa)


@app.route('/video_feed')
def video_feed():
    return Response(gen(),
                    mimetype='multipart/x-mixed-replace; boundary=frame')



if __name__ == '__main__':
    app.run(debug=True)
